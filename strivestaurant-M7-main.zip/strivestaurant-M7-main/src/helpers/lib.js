const upperName = (name) => name.toUpperCase()

export default upperName
