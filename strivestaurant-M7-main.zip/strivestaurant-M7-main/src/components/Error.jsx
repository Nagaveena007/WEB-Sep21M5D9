import { Alert } from 'react-bootstrap'

const Error = () => <Alert variant="danger">
    Whoopsy
</Alert>

export default Error