const NotFound = () => (
    <div className="text-center">
        <h2>404 - This Page doesn't exist :(</h2>
    </div>
)

export default NotFound